package surfers;

public class Surfer {
//TODO
}
