package surfers;


public class Beach {
//TODO
}
