package iterable_iterator_comparable_comparator.exc.ex06;

import com.sun.tools.attach.AgentInitializationException;

import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class Main {

    public static void main(String[] args) {


        Scanner sc = new Scanner(System.in);

        Set<Person> peopleByName = new TreeSet<>(new NameComparator());
        Set<Person> peopleByAge = new TreeSet<>(new AgeComparator());

        int n = Integer.parseInt(sc.nextLine());

        while (n-- > 0) {
            String[] tokens = sc.nextLine().split("\\s+");
            String name = tokens[0];
            int age = Integer.parseInt(tokens[1]);
            Person person = new Person(name, age);
            peopleByName.add(person);
            peopleByAge.add(person);

        }

        peopleByName.forEach(System.out::println);
        peopleByAge.forEach(System.out::println);
    }
}
