package DefiningClasses.Excersises.ex8_review_for_exam;

import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        List<String> relationships = new LinkedList<>();
        List<Person> persons = new LinkedList<>();

        String personToPrint = scanner.nextLine();

        String input = scanner.nextLine();
        while(!input.equals("End")){
            if (input.contains("-")) {
                relationships.add(input);
            }else {
                String[] tokens = input.split("\\s+");
                String name = tokens[0] + " " + tokens[1];
                String birthday = tokens[2];
                Person person = new Person(name, birthday);
                persons.add(person);
            }
            input = scanner.nextLine();
        }

        String parentName;
        String parentDate;
        String childName;
        String childDate;

        for (String relationship : relationships) {
            String[] tokens = relationship.split("\\s+-\\s+");

            if (!tokens[0].contains("/") && !tokens[1].contains("/")) {
                childDate = "";
                parentDate = "";
                parentName = tokens[0];
                childName = tokens[1];
            } else if (tokens[0].contains("/") && !tokens[1].contains("/")) {
                childDate = "";
                parentName = "";
                parentDate = tokens[0];
                childName = tokens[1];
            } else if (!tokens[0].contains("/") && tokens[1].contains("/")) {
                    childName = "";
                    parentDate = "";
                    parentName = tokens[0];
                    childDate = tokens[1];
                } else {
                    parentName = "";
                    childName = "";
                    parentDate = tokens[0];
                    childDate = tokens[1];
                }

            String finalParentName = parentName;
            String finalParentDate = parentDate;
            String finalChildName = childName;
            String finalChildDate = childDate;
            persons.stream()
                    .filter(p -> p.getName().equals(finalParentName) || p.getBirthday().equals(finalParentDate))
                    .findFirst()
                    .ifPresent(parent -> {
                        persons.stream()
                                .filter(c -> c.getName().equals(finalChildName) || c.getBirthday().equals(finalChildDate))
                                .findFirst()
                                .ifPresent(child -> {
                                    parent.addChildren(child);
                                    child.addParents(parent);
                                });
                    });
            }

        persons.stream()
                .filter(p -> p.getName().equals(personToPrint) || p.getBirthday().equals(personToPrint))
                .forEach(System.out::println);










    }
}
