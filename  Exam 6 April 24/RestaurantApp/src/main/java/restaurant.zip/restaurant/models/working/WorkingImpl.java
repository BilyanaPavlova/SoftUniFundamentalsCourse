package restaurant.models.working;

import restaurant.models.client.Client;
import restaurant.models.waiter.Waiter;

import java.util.Collection;
import java.util.Iterator;

public class WorkingImpl implements Working{

    @Override
    public void takingOrders(Client client, Collection<Waiter> waiters) {

        Iterator<Waiter> waiterIterator = waiters.iterator();

        while (!client.getClientOrders().isEmpty() && waiterIterator.hasNext()) {
            Waiter waiter = waiterIterator.next();

            while (waiter.canWork() && !client.getClientOrders().isEmpty()) {
                String order = client.getClientOrders().iterator().next();
                waiter.takenOrders().getOrdersList().add(order);
                waiter.work();
                client.getClientOrders().remove(order);
            }
        }
    }


}
