package busyWaiters;


import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class RestaurantTests {

    @Test
    public void testRestaurant() {
        Restaurant restaurant = new Restaurant("Food", 20);
        Assertions.assertEquals("Food", restaurant.getName());
        Assertions.assertEquals(20, restaurant.getCapacity());
        Assertions.assertEquals(0, restaurant.getCount());
    }

    @Test
    public void testGetWiters() {
        Restaurant restaurant = new Restaurant("Food", 20);
        Assertions.assertNotNull(restaurant.getWaiters());
    }

    @Test
    public void testSetNameNullThrows(){
        NullPointerException exception = Assertions.assertThrows(NullPointerException.class, () -> new Restaurant(null, 20));
        Assertions.assertEquals("Invalid client!", exception.getMessage());
    }

    @Test
    public void testSetNameEmptyThrows(){
        NullPointerException exception = Assertions.assertThrows(NullPointerException.class, () -> new Restaurant("", 20));
        Assertions.assertEquals("Invalid client!", exception.getMessage());
    }

    @Test
    public  void testSetCapacityThrows() {
        IllegalArgumentException exception = Assertions.assertThrows(IllegalArgumentException.class, () -> new Restaurant("Food", -1));
        Assertions.assertEquals("Invalid capacity!", exception.getMessage());
    }

    @Test
    public void testAddFullTimeWaiter() {
        Restaurant restaurant = new Restaurant("Food", 20);
        FullTimeWaiter waiter = new FullTimeWaiter("John", 1000);
        restaurant.addFullTimeWaiter(waiter);
        Assertions.assertEquals(1, restaurant.getCount());
    }

    @Test
    public void testAddFullTimeWaiterThrows() {
        Restaurant restaurant = new Restaurant("Food", 20);
        FullTimeWaiter waiter = new FullTimeWaiter("John", 1000);
        restaurant.addFullTimeWaiter(waiter);
        Assertions.assertThrows(IllegalArgumentException.class, () -> restaurant.addFullTimeWaiter(waiter));
    }

    @Test
    public void testAddFullTimeWaiterThrowsNoMorePlaces() {
        Restaurant restaurant = new Restaurant("Food", 1);
        FullTimeWaiter waiter = new FullTimeWaiter("John", 1000);
        restaurant.addFullTimeWaiter(waiter);
        FullTimeWaiter waiter2 = new FullTimeWaiter("Peter", 1000);
        IllegalArgumentException exception = Assertions.assertThrows(IllegalArgumentException.class, () -> restaurant.addFullTimeWaiter(waiter2));
        Assertions.assertEquals("No more places!", exception.getMessage());
    }

    //how to check the message of the exception thrown
    @Test
    public void testAddFullTimeWaiterThrowsNoMorePlacesMessage() {
        Restaurant restaurant = new Restaurant("Food", 1);
        FullTimeWaiter waiter = new FullTimeWaiter("John", 1000);
        restaurant.addFullTimeWaiter(waiter);
        FullTimeWaiter waiter2 = new FullTimeWaiter("Peter", 1000);
        IllegalArgumentException exception = Assertions.assertThrows(IllegalArgumentException.class, () -> restaurant.addFullTimeWaiter(waiter2));
        Assertions.assertEquals("No more places!", exception.getMessage());
    }


    //check if waiter does not exist and we try to add him
    @Test
    public void testAddFullTimeWaiterThrowsWaiterExist() {
        Restaurant restaurant = new Restaurant("Food", 20);
        FullTimeWaiter waiter = new FullTimeWaiter("John", 1000);
        restaurant.addFullTimeWaiter(waiter);
        FullTimeWaiter waiter2 = new FullTimeWaiter("John", 1000);
        Assertions.assertThrows(IllegalArgumentException.class, () -> restaurant.addFullTimeWaiter(waiter2));
    }



    @Test
    public void testRemoveFullTimeWaiter() {
        Restaurant restaurant = new Restaurant("Food", 20);
        FullTimeWaiter waiter = new FullTimeWaiter("John", 1000);
        restaurant.addFullTimeWaiter(waiter);
        Assertions.assertTrue(restaurant.removeFullTimeWaiter("John"));
    }

    @Test
    public void testRemoveFullTimeWaiterReturnsFalse() {
        Restaurant restaurant = new Restaurant("Food", 20);
        FullTimeWaiter waiter = new FullTimeWaiter("John", 1000);
        restaurant.addFullTimeWaiter(waiter);
        Assertions.assertFalse(restaurant.removeFullTimeWaiter("Peter"));
    }

    //check setCapacity of waiters
    @Test
    public void testSetCapacity() {
        Restaurant restaurant = new Restaurant("Food", 1);
        FullTimeWaiter waiter = new FullTimeWaiter("John", 1000);
        restaurant.addFullTimeWaiter(waiter);
        FullTimeWaiter waiter2 = new FullTimeWaiter("Peter", 1000);
        Assertions.assertThrows(IllegalArgumentException.class, () -> restaurant.addFullTimeWaiter(waiter2));
    }




}
